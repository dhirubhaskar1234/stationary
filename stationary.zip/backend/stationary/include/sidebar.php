<div class="site-menubar">
      <div class="site-menubar-body">
        <div>
          <div>
            <ul class="site-menu" data-plugin="menu" id="side-menu">

                <li class="site-menu-item has-sub">
                    <a href="javascript:void(0)">
                        <i class="site-menu-icon wb-dashboard" aria-hidden="true">
                        </i>
                        <span class="site-menu-title">Dashboard
                  </span>
                        <div class="site-menu-badge">

                        </div>
                    </a>
                    <ul class="site-menu-sub">
                        <li class="site-menu-item active">
                            <a href="index.php">
                      <span class="site-menu-title">View
                      </span>
                            </a>
                        </li>

                    </ul>

                </li>


                <!--             sidebar product start-->


                <li class="site-menu-item has-sub">
                <a href="javascript:void(0)">
                  <i class="site-menu-icon wb-dashboard" aria-hidden="true">
                  </i>
                  <span class="site-menu-title">Product
                  </span>
                  <div class="site-menu-badge">

                  </div>
                </a>
                <ul class="site-menu-sub">
                  <li class="site-menu-item active">
                    <a href="add_product.php">
                      <span class="site-menu-title">Add Product
                      </span>
                    </a>
                  </li>
                    <li class="site-menu-item active">
                        <a href="view_product.php">
                      <span class="site-menu-title">View Product
                      </span>
                        </a>
                    </li>
                    <li class="site-menu-item active">
                        <a href="add_size.php">
                      <span class="site-menu-title">Add Size
                      </span>
                        </a>
                    </li>
                </ul>

              </li>

                <!--                Side bar end-->


                <!--                side bar category start-->
                <li class="site-menu-item has-sub">
                    <a href="javascript:void(0)">
                        <i class="site-menu-icon wb-dashboard" aria-hidden="true">
                        </i>
                        <span class="site-menu-title">Category
                  </span>
                        <div class="site-menu-badge">

                        </div>
                    </a>
                    <ul class="site-menu-sub">
                        <li class="site-menu-item active">
                            <a href="add_categories.php">
                      <span class="site-menu-title">View category
                      </span>
                            </a>
                        </li>

                    </ul>
                    <ul class="site-menu-sub">
                        <li class="site-menu-item active">
                            <a href="add_brand.php">
                      <span class="site-menu-title">View brand
                      </span>
                            </a>
                        </li>

                    </ul>

                </li>




                                    <!--sidebar category end-->

            </ul>
          </div>
        </div>
      </div>
      <div class="site-menubar-footer">
        <a href="php/logout.php" data-placement="top" data-toggle="tooltip" data-original-title="Logout">
          <span class="icon wb-power" aria-hidden="true">
          </span>
        </a>
      </div>
    </div>
